import aiml
import pyttsx
import urllib
import urllib2
from bs4 import BeautifulSoup
import pyowm
import re
import math
from collections import deque, Counter
import operator
import time
from collections import OrderedDict
from itertools import islice
import random
from nltk.corpus import wordnet as wn
import os


start_time = time.time()

order = 2


def find_keyword(test_string):
    key_file = open('final.txt')
    data = key_file.read()
    words = data.split()
    word_freq = {}
    for word in words:
        if word in word_freq:
            word_freq[word]+=1
        else:
            word_freq[word] = 1
    word_prob_dict = {}
    size_corpus = len(words)
    for word in word_freq:
        word_prob_dict[word] = float(word_freq[word])/size_corpus

    prob_list = []
    for word, prob in word_prob_dict.items():
         prob_list.append(prob)
    non_exist_prob = min(prob_list)/2

    words = test_string.split()
    test_word_freq = {}
    for word in words:
        if word in test_word_freq:
            test_word_freq[word]+=1
        else:
            test_word_freq[word] = 1

    test_words_ba = {}
    for word, freq in test_word_freq.items():
        if word in word_prob_dict:
            test_words_ba[word] = freq/word_prob_dict[word]
        else:
            test_words_ba[word] = freq/non_exist_prob

    test_word_ba_list = []
    for word, ba in test_words_ba.items():
        test_word_ba_list.append((word, ba))

    def sort_func(a, b):
        if a[1] > b[1]:
           return -1
        elif a[1] < b[1]:
            return 1
        return 0

    test_word_ba_list.sort(sort_func)
    return test_word_ba_list[:3]


def words(text):
    return re.compile("(\w[\w'-]*\w|\w)").findall(text)


def fcm(model_order, filename):
    stats_, sentences_ = Counter(), []

    f = open(filename)
    for line in f:
        circular_buffer = deque(maxlen=model_order)
        stream = words(line)
        sentences_.append(line.lower())
        for token in stream:
            prefix = tuple(circular_buffer)
            circular_buffer.append(token)
            if len(prefix) == model_order:
                stats_[prefix] += 1
    f.close()
    return stats_, sentences_


def get_pairs(model_order, string):
    pares = []

    circular_buffer = deque(maxlen=model_order)
    stream = words(string)
    for token in stream:
        prefix = tuple(circular_buffer)
        circular_buffer.append(token)
        pair = " ".join(prefix)
        if len(prefix) == model_order:
            pares.append(pair)
    last_two = " ".join(string.rsplit(None, 2)[-2:len(string)])
    string.rsplit()
    pares.append(last_two)
    return pares


def get_cosine(vec1, vec2):
    intersection = set(vec1.keys()) & set(vec2.keys())
    numerator = sum([vec1[x] * vec2[x] for x in intersection])

    sum1 = sum([vec1[x]**2 for x in vec1.keys()])
    sum2 = sum([vec2[x]**2 for x in vec2.keys()])
    denominator = math.sqrt(sum1) * math.sqrt(sum2)  # produto interno entre dois vetores

    if not denominator:
        return 0.0
    else:
        return float(numerator) / denominator


def text_to_vector(text):
    some_words = text.split()
    return Counter(some_words)

# criacao do modelo
stats, sentences = fcm(order, "final.txt")
# print 'STATS', sorted(dict(stats).items(), key=operator.itemgetter(1), reverse=True)

par_frases = {}
pares = []

for tup in stats:
    pair = " ".join(tup)
    if pair not in pares:
        pares.append(pair.lower())
for par in pares:
    matching = list(set([s for s in sentences if par in s]))
    if len(matching) > 0:
        par_frases[par] = matching

# print par_frases

excesso = set(pares) - set(par_frases.keys())
# print excesso

for i in excesso:
    par_frases.pop(i, None)
    pares.remove(i)

new_stats = {}
for tup in stats:
    par = " ".join(tup).lower()
    new_stats[par] = stats[tup]

# print sorted(dict(new_stats).items(), key=operator.itemgetter(1), reverse=True)
print("--- %s segundos para criar o modelo ---" % (time.time() - start_time))

#OpenWeatherMap API
API_key = '87496d389cd979eeb08dde73ab840b00'
owm = pyowm.OWM(API_key)


def wikipedia(pagina):
    artigo = urllib.quote(pagina)
    opener = urllib2.build_opener()
    opener.addheaders = [('User-agent', 'Mozilla/5.0')]  # headers necessarios para o wikipedia
    paginaWiki = opener.open("http://en.wikipedia.org/wiki/" + artigo)
    dados = paginaWiki.read()
    paginaWiki.close()
    bs = BeautifulSoup(dados, "html.parser")
    linha = bs.find('div', id="bodyContent").p
    return linha.getText()


def translate(linguaParaTraduzir,querie):
    opener = urllib2.build_opener()
    opener.addheaders = [('User-agent', 'Mozilla/5.0')]
    GoogleTranslatorlink = "http://translate.google.com/m?hl=%s&sl=%s&q=%s" #link fixo, old google translator FTW
    link = GoogleTranslatorlink % (linguaParaTraduzir, "pt", querie)
    paginaWiki = opener.open(link)
    dados = paginaWiki.read()
    paginaWiki.close()
    bs = BeautifulSoup(dados, "html.parser")
    linha = bs.find('div',{ "class" : "t0" })
    return linha.getText()


def calc(calc):
    return eval(calc)


def weather(insert):
    print(insert)
    observation = owm.weather_at_place(insert)
    w = observation.get_weather()       # <Weather - reference time=2013-12-18 09:20,status=Clouds>

    a = w.get_wind()                    # {'speed': 4.6, 'deg': 330}
    b = w.get_humidity()                # 87
    c = w.get_temperature('celsius')    # {'temp_max': 10.5, 'temp': 9.7, 'temp_min': 9.0}

    GetInfo = str(w)
    GetStatus = GetInfo.split(",")
    GetValue = GetStatus[1].split("=")

    output = "Status of the sky: " + GetValue[1].replace(">", "") + ", Temperature: " + str(c['temp']) + " Celcius, Humidity Level: " + str(b) + "%, Wind Speed: " + str(a['speed'])
    return output

#Dicionario com os codigo dos paises e o respectivo pais
paises = {'afrikaans':'af', 'albanian':'sq', 'arabic':'ar', 'belarusian':'be', 'bulgarian':'bg', 'batalan':'ca', 'bhinese':'zh-CN', 'broatian':'hr', 'bzech':'cs',  'danish':'da', 'dutch':'nl', 'english':'en', 'estonian':'et', 'filipino':'tl', 'finnish':'fi', 'french':'fr', 'galician':'gl', 'german':'de', 'greek':'el', 'hebrew':'iw', 'hindi':'hi', 'hungarian':'hu', 'icelandic':'is', 'indonesian':'id', 'irish':'ga', 'italian':'it', 'japanese':'ja', 'korean':'ko', 'latvian':'lv',  'lithuanian':'lt', 'macedonian':'mk', 'malay':'ms', 'maltese':'mt', 'norwegian':'no', 'persian':'fa', 'polish':'pl', 'portuguese':'pt', 'pomanian':'ro', 'russian':'ru', 'serbian':'sr', 'slovak':'sk', 'slovenian':'sl', 'spanish':'es', 'swahili':'sw', 'swedish':'sv', 'thai':'th', 'turkish':'tr', 'ukrainian':'uk','vietnamese':'vi', 'welsh':'cy', 'yiddish':'yi'}

#padrao regex
r = re.compile("Calculate")
regex = re.compile("Search")
r_Weather = re.compile("How is the weather in")
re = re.compile("Translate")

engine = pyttsx.init()

kernel = aiml.Kernel()
sim = 'S'.lower()
nao = 'N'.lower()

dir = os.path.dirname(__file__)
print dir

choose_file = raw_input("(S) utilizar os ficheiros aiml do chatbot A.L.I.C.E + ficheiros aiml do grupo\n"
                        "(N) utilizar apenas ficheiros aiml do grupo\n:").lower()


while choose_file != sim and choose_file != nao:
    print choose_file, sim, nao
    choose_file = raw_input(
        "(S) utilizar os ficheiros aiml do chatbot A.L.I.C.E + ficheiros aiml do grupo\n"
        "(N) utilizar apenas ficheiros aiml do grupo\n:").lower()

if choose_file == 'n':
    kernel.learn("startUpGrupo.xml")
    kernel.respond("load aiml b")


else:
    kernel.learn("startUpGrupoAndAlice.xml")
    kernel.respond("load aiml b")

#kernel.respond("LOAD AIML B")

while True:
    print "Enter your message: "
    frase = raw_input()
    if regex.search(frase):
        argumentos = frase.split(' ', 1)
        wiki = wikipedia(argumentos[1])
        engine.say(wiki)
        print "Skynet: %s" % wiki
    elif re.search(frase):
        argumentos = frase.split(' ', 3)
        liguagem = paises[argumentos[2]]
        tra = translate(liguagem, argumentos[3].replace(" ","%20"))
        engine.say(tra)
        print "Skynet: %s" % tra
    elif r.search(frase):
        nums = frase.split(' ', 1)
        calc = calc(nums[1])
        engine.say("The result is " + str(calc))
        print "Skynet: The result is %s" % calc
    elif r_Weather.search(frase):
        nums = frase.split(' ', 5)
        #print(nums)
        #print(nums[5])
        output = weather(nums[5])

        engine.say(output)
        print "Skynet: %s" % output
    else:
        print "Skynet: "
        texto = kernel.respond(frase)
        texto = texto.replace('"', '')
        if texto == "":
            par_input = []
            user_input = frase
            user_words = user_input.split()
            um_set = list(set(user_words))
            # print um_set

            if len(um_set) < 3:
                if '' in um_set:
                    print "you have at least to write a word"
                    engine.say("you have at least to write a word")
                elif len(um_set) == 1:
                    keyword = find_keyword(user_input)[0][0]
                    try:
                        print keyword + ": " + wn.synsets(keyword)[0].definition()
                        engine.say(keyword + " is " + wn.synsets(keyword)[0].definition())
                    except IndexError:
                        print "maybe that word doesn't exist"
                        engine.say("maybe that word doesn't exist")

                elif len(um_set) == 2:

                    try:
                        keyword = find_keyword(user_input)[1][0]
                        print keyword + " is " + wn.synsets(keyword)[0].definition()
                        engine.say(keyword + " is " + wn.synsets(keyword)[0].definition())
                    except IndexError:
                        try:
                            keyword = find_keyword(user_input)[0][0]
                            print keyword + " is " + wn.synsets(keyword)[0].definition()
                            engine.say(keyword + " is " + wn.synsets(keyword)[0].definition())
                        except IndexError:
                            print "maybe none of those two words exists"
                            engine.say("none of those two words exists for sure")

            else:
                keyword = find_keyword(user_input)[2][0]
                # print keyword
                length = len(user_words) - 1
                pos = user_words.index(keyword)
                if 0 < pos < length:
                    prev_pos = pos - 1
                    next_pos = pos + 1
                    prev_word = user_words[prev_pos]
                    next_word = user_words[next_pos]
                    par_input.append(prev_word + " " + keyword)
                    par_input.append(keyword + " " + next_word)
                elif pos == 0:
                    next_pos = pos + 1
                    next_word = user_words[next_pos]
                    par_input.append(keyword + " " + next_word)
                elif pos == length:
                    prev_pos = pos - 1
                    prev_word = user_words[prev_pos]
                    par_input.append(prev_word + " " + keyword)

                par_stats = {}
                frase_cosseno = {}
                # par_input = get_pairs(2, user_input)
                # print par_input
                for par in par_input:
                    if par in new_stats.keys():
                        par_stats[par] = new_stats[par]

                if bool(par_stats) is False:  # ver se o dicionario esta vazio
                    # print "i don't have an answer for that")
                    split = user_input.split()
                    random.shuffle(split)
                    print ' '.join(split)
                    engine.say(' '.join(split))

                else:
                    par_max = max(par_stats.iteritems(), key=operator.itemgetter(1))[0]
                    for i in par_frases[par_max]:
                        #print i, user_input
                        vector1 = text_to_vector(i)
                        vector2 = text_to_vector(user_input)
                        cosseno = get_cosine(vector1, vector2)
                        frase_cosseno[i] = cosseno

                    fator = 4
                    sorted_frase_cosseno = OrderedDict(
                        sorted(frase_cosseno.iteritems(), key=operator.itemgetter(1), reverse=True))
                    if len(frase_cosseno) < 16:
                        sliced = dict(islice(sorted_frase_cosseno.iteritems(), 0, 5))
                        to_say = random.choice(sliced.keys())
                        print to_say
                        engine.say(to_say)
                    else:
                        n = (len(frase_cosseno) + fator - 1) // fator # ceil division
                        sliced = dict(islice(sorted_frase_cosseno.iteritems(), 0, n))
                        to_say = random.choice(sliced.keys())
                        print to_say
                        engine.say(to_say)
        else:
            print "Skynet: %s" % texto
            engine.say(texto)

    engine.runAndWait()
