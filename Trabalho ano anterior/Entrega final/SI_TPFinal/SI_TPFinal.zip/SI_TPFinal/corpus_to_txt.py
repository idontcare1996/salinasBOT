from nltk.corpus import webtext
import os
import re


text_file = open("texto.txt", "w")

for fileid in webtext.fileids():
    if fileid == "firefox.txt" or fileid == "wine.txt" or fileid == "singles.txt" or fileid == "pirates.txt" or fileid == "grail.txt":
        pass
    else:
        print fileid
        text_file.write(webtext.raw(fileid).encode('utf-8'))

text_file.close()

lines = [i for i in open("texto.txt") if i[:-1]]
#print lines

text_file = open("final.txt", "w")

keyword = ':'

for line in lines:
    line = line.replace("! ?", "!?")
    line = line.replace("! ! !", "!")
    line = line.replace("! !", "!")
    line = line.replace("! .", "!")


    before_keyowrd, kw, after_keyword = line.partition(keyword)
    text_file.write(after_keyword.strip('\r\n'))
    text_file.write("\n")

text_file.close()

lines = [i for i in open("final.txt") if i[:-1]]

os.remove("final.txt")

text_file = open("final.txt", "w")

keyword = ':'

for line in lines:
    line = re.sub("([\(\[]).*?([\)\]])", "\g<1>\g<2>", line)
    line = line.replace("[]", "")
    line = line.replace(',', '')
    line = line.replace(';', '')
    line = line.replace('...', '')
    line = line.replace('$', '')
    line = line.replace('"', '')
    line = line.replace("'cause", 'because')
    line = line.replace("fuckin'", 'fucking')
    line = line.replace("yo'", 'your')
    line = line.replace("'em", "them")
    line = line.replace("&", 'and')
    line = line.replace("  ", ' ')
    line = re.sub(r"([.?!])(?=\s*[a-zA-Z0-9])\s*", r"\1\n", line)
    line = line.lstrip(' ')
    text_file.write(line.strip('\r\n'))
    text_file.write("\n")

os.remove("texto.txt")


