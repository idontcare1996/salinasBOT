1 - Para instalar nltk:
	Na linha de comandos:
	- $pip install -U nltk

2 - Para transferir corpora para nltk:
	- Executar o módulo dwnld_corpora.py.
	- Irá aparecer uma interface gráfica onde é possível transferir corpora.
	- Clicar no botão Download (a transferência irá demorar algum tempo).
	
3 - Executar o módulo test_wn.py.

